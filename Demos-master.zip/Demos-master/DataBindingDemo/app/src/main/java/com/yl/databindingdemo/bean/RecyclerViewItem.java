package com.yl.databindingdemo.bean;

/**
 * RecyclerView
 * Created by yangle on 2017/7/21.
 */

public class RecyclerViewItem {

    private String content;

    public RecyclerViewItem(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
