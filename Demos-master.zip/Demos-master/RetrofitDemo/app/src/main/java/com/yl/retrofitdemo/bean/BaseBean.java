package com.yl.retrofitdemo.bean;

/**
 * Bean基类
 * Created by yangle on 2017/6/19.
 */

public class BaseBean {
}
