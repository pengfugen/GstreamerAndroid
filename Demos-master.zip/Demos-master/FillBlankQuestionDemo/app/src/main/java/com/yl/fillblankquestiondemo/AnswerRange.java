package com.yl.fillblankquestiondemo;

/**
 * 答案范围
 * Created by yangle on 2017/9/2.
 */

public class AnswerRange {

    public int start;
    public int end;

    public AnswerRange(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
