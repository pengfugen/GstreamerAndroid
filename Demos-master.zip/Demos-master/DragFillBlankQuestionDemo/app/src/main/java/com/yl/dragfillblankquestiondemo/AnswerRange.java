package com.yl.dragfillblankquestiondemo;

/**
 * 答案范围
 * Created by yangle on 2017/10/9.
 */

public class AnswerRange {

    public int start;
    public int end;

    public AnswerRange(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
