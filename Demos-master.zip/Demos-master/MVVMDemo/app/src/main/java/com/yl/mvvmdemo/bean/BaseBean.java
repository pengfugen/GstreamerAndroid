package com.yl.mvvmdemo.bean;

import android.databinding.BaseObservable;

/**
 * Bean基类
 * Created by yangle on 2017/7/26.
 */

public class BaseBean extends BaseObservable {
}
