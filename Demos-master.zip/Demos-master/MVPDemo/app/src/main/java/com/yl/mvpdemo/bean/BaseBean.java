package com.yl.mvpdemo.bean;

/**
 * Bean基类
 * Created by yangle on 2017/6/26.
 */

public class BaseBean {
}
