package com.yl.mvpdemo.ui;

import com.trello.rxlifecycle2.components.support.RxAppCompatActivity;

/**
 * Created by yangle on 2017/6/28.
 */

public class BaseActivity extends RxAppCompatActivity {
}
